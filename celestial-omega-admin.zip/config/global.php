<?php

return [
    'router_prefix' => '/Omega',
];
